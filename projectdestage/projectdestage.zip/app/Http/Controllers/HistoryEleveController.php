<?php

namespace App\Http\Controllers;
use App\Models\HistoriqueSoldesEleve;





class HistoriqueSoldesEleveController extends Controller
{

    //TODO working ?
    public function GetHistoryEleve(){
        $data = HistoriqueSoldesEleve::all()->paginate(15);

        return response()->json($data);


    }

    //TODO Not working
    public function GetHistoryOneEleve($id){
        $data = HistoriqueSoldesEleve::all()->where('eleve_id','=',$id)->paginate(15);
        return response()->json($data);
    }

}
