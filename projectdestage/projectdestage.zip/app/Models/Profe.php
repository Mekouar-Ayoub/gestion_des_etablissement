<?php

namespace App\Models;

// use Illuminate\Contracts\Auth\MustVerifyEmail;

use Laravel\Sanctum\HasApiTokens;
use Tymon\JWTAuth\Contracts\JWTSubject;
use Illuminate\Notifications\Notifiable;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;

class Profe extends Authenticatable implements JWTSubject
{
    use HasApiTokens, HasFactory, Notifiable;



    public function getJWTIdentifier()
    {
        return $this->getKey();
    }



    public function getJWTCustomClaims()
    {
        return [];
    }
    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    public $table = 'profes';
    protected $fillable =[
        'nom',
        'prenom',
        'tel',
        'email',
        'password',
        'adress',
        'instrument',
        'tarif',
        'solde',
        'type'
    ];

    //TODO working ?
    public function cours()
    {
        return $this->hasMany(Coure::class);
    }

    //Working ?
    public function history()
    {
        return $this->hasMany(CompteProf::class, 'prof_id');
    }

    //Working ?
    public function historyEcole()
    {
        return $this->hasMany(CompteEcole::class, 'prof_id');
    }

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var array<int, string>
     */
    protected $hidden = [
        'password',
        'remember_token',
    ];

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
        'password' => 'hashed',
    ];
}
